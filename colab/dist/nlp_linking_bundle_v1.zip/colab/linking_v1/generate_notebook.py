"""Tạo file Jupyter Notebook LienKet_ViDeBERTa_Drive.ipynb chuẩn định dạng JSON."""

import json
from pathlib import Path

def create_notebook():
    cells = []

    def add_md(text):
        cells.append({
            "cell_type": "markdown",
            "metadata": {},
            "source": text.splitlines(keepends=True)
        })

    def add_code(text):
        cells.append({
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": text.splitlines(keepends=True)
        })

    # Ô 0: Tiêu đề Markdown
    add_md(
        "# Thí nghiệm Liên kết thực thể địa chỉ (Neural Entity Linking v1)\n"
        "### Kiến trúc Shared Frozen ViDeBERTa-xsmall Encoder + Candidate Cache + Neural Linking Head\n\n"
        "Notebook này được thiết kế để chạy **hoàn toàn tự động 100% (Run all)** trên Google Colab với T4 GPU.\n"
        "- **Tác vụ**: Huấn luyện Đầu liên kết / Chấm ứng viên Tên - Mã hành chính 01/07/2025.\n"
        "- **Nguyên tắc**: Encoder ViDeBERTa 70M đóng băng hoàn toàn (`requires_grad = False`). Chỉ cập nhật trọng số Neural Linking Head.\n"
        "- **Tự động hóa**: Toàn bộ dữ liệu, bundle và checkpoint được nạp và lưu trữ trực tiếp trên Google Drive, không cần upload ZIP hay cấu hình đường dẫn thủ công.\n\n"
        "**Hướng dẫn nhanh:**\n"
        "1. Chọn **Runtime → Change runtime type → T4 GPU**.\n"
        "2. Nhấn **Runtime → Run all** (hoặc `Ctrl + F9`) và cấp quyền truy cập Google Drive khi được yêu cầu."
    )

    # Ô 1: Kiểm tra GPU
    add_code(
        "import sys, subprocess, torch\n"
        "print('=== KIỂM TRA MÔI TRƯỜNG PHẦN CỨNG ===')\n"
        "print('Python:', sys.version)\n"
        "print('PyTorch:', torch.__version__)\n"
        "print('CUDA Khả dụng:', torch.cuda.is_available())\n"
        "if torch.cuda.is_available():\n"
        "    print('GPU Thiết bị:', torch.cuda.get_device_name(0))\n"
        "    subprocess.run(['nvidia-smi'], check=False)\n"
        "else:\n"
        "    print('[CẢNH BÁO] Không tìm thấy GPU. Hãy chọn Runtime -> Change runtime type -> T4 GPU để tăng tốc!')\n"
    )

    # Ô 2: Mount Drive
    add_code(
        "from google.colab import drive\n"
        "from pathlib import Path\n"
        "import os, sys, shutil, zipfile, hashlib, subprocess\n\n"
        "print('=== MOUNT GOOGLE DRIVE ===')\n"
        "drive.mount('/content/drive')\n\n"
        "DRIVE_BASE = Path('/content/drive/MyDrive/nlp_chuan_hoa_dia_chi')\n"
        "EXP_DIR = DRIVE_BASE / 'linking_v1'\n"
        "PROJECT_DIR = Path('/content/nlp_chuan_hoa_dia_chi')\n\n"
        "print('Thư mục gốc Drive:', DRIVE_BASE)\n"
        "print('Thư mục thí nghiệm:', EXP_DIR)\n"
        "assert DRIVE_BASE.exists(), f'Không tìm thấy {DRIVE_BASE} trên Drive!'\n"
        "assert EXP_DIR.exists(), f'Không tìm thấy {EXP_DIR} trên Drive!'\n"
    )

    # Ô 3: Giải nén Bundle & Chuyển thư mục làm việc
    add_code(
        "print('=== GIẢI NÉN BUNDLE DỰ ÁN TỰ THÂN ===')\n"
        "BUNDLE_ZIP = EXP_DIR / 'nlp_linking_bundle_v1.zip'\n"
        "assert BUNDLE_ZIP.exists(), f'Lỗi: Không tìm thấy file bundle tại {BUNDLE_ZIP}'\n\n"
        "if PROJECT_DIR.exists():\n"
        "    shutil.rmtree(PROJECT_DIR)\n"
        "PROJECT_DIR.mkdir(parents=True, exist_ok=True)\n\n"
        "print(f'Đang giải nén {BUNDLE_ZIP.name} ({BUNDLE_ZIP.stat().st_size / 2**20:.2f} MB)...')\n"
        "with zipfile.ZipFile(BUNDLE_ZIP, 'r') as z:\n"
        "    z.extractall(PROJECT_DIR)\n\n"
        "os.chdir(PROJECT_DIR)\n"
        "if str(PROJECT_DIR) not in sys.path:\n"
        "    sys.path.insert(0, str(PROJECT_DIR))\n\n"
        "print('Giải nén thành công vào:', PROJECT_DIR)\n"
        "print('Số tệp tin giải nén:', len(list(PROJECT_DIR.rglob('*'))))\n"
    )

    # Ô 4: Cài đặt Dependencies
    add_code(
        "print('=== CÀI ĐẶT CÁC THƯ VIỆN PHỤ THUỘC ===')\n"
        "subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', '-r', 'colab/linking_v1/requirements.txt'], check=True)\n"
        "print('Cài đặt thư viện hoàn tất thành công!')\n"
    )

    # Ô 5: Chạy Unit Tests Xác minh Môi trường
    add_code(
        "print('=== CHẠY KIỂM THỬ ĐỘC LẬP (UNIT TESTS) ===')\n"
        "subprocess.run([sys.executable, '-m', 'unittest', 'tests/test_lien_ket_v1.py'], check=True)\n"
        "print('Tất cả unit tests đã PASS 100%!')\n"
    )

    # Ô 6: Thiết lập Checkpoint ViDeBERTa & Thư mục Lưu Trữ
    add_code(
        "print('=== THIẾT LẬP CHECKPOINT VÀ CACHE ===')\n"
        "VIDEBERTA_MODEL_DIR = DRIVE_BASE / 'videberta_v1_01/model'\n"
        "assert VIDEBERTA_MODEL_DIR.exists(), f'Không tìm thấy checkpoint ViDeBERTa tại {VIDEBERTA_MODEL_DIR}'\n\n"
        "OUTPUT_CKPT_DIR = EXP_DIR / 'checkpoints'\n"
        "CACHE_DIR = EXP_DIR / 'cache'\n"
        "REPORT_DIR = EXP_DIR / 'reports'\n\n"
        "OUTPUT_CKPT_DIR.mkdir(parents=True, exist_ok=True)\n"
        "CACHE_DIR.mkdir(parents=True, exist_ok=True)\n"
        "REPORT_DIR.mkdir(parents=True, exist_ok=True)\n\n"
        "print('ViDeBERTa Checkpoint:', VIDEBERTA_MODEL_DIR)\n"
        "print('Checkpoints Output:  ', OUTPUT_CKPT_DIR)\n"
        "print('Candidate Cache Dir: ', CACHE_DIR)\n"
        "print('Reports Output:      ', REPORT_DIR)\n"
    )

    # Ô 7: Huấn luyện Đầu Liên Kết (Pilot Run + Full Training)
    add_code(
        "print('=== HUẤN LUYỆN ĐẦU LIÊN KẾT THỰC THỂ (NEURAL LINKING HEAD) ===')\n"
        "# ViDeBERTa encoder đóng băng 100%, chỉ linking head nhận gradient\n"
        "# Chạy pilot đo throughput và in bảng ETA trước khi train full\n"
        "train_cmd = [\n"
        "    sys.executable, '-u', 'colab/linking_v1/train_linking.py',\n"
        "    '--model_dir', str(VIDEBERTA_MODEL_DIR),\n"
        "    '--data_path', 'data/train_dev/duyet_v2_01/train_cnn_ket_hop.jsonl',\n"
        "    '--output_dir', str(OUTPUT_CKPT_DIR),\n"
        "    '--cache_dir', str(CACHE_DIR),\n"
        "    '--epochs', '5',\n"
        "    '--batch_size', '32',\n"
        "    '--lr', '0.001',\n"
        "    '--pilot_steps', '20',\n"
        "    '--device', 'auto',\n"
        "    '--resume'\n"
        "]\n"
        "subprocess.run(train_cmd, check=True)\n"
    )

    # Ô 8: Đánh giá Độc lập Linking và End-to-End Pipeline
    add_code(
        "print('=== ĐÁNH GIÁ CHẤT LƯỢNG VÀ ĐỘ TRỄ CPU ===')\n"
        "eval_cmd = [\n"
        "    sys.executable, '-u', 'colab/linking_v1/evaluate_linking.py',\n"
        "    '--model_dir', str(VIDEBERTA_MODEL_DIR),\n"
        "    '--head_path', str(OUTPUT_CKPT_DIR / 'best_linking_head.pt'),\n"
        "    '--cache_dir', str(CACHE_DIR),\n"
        "    '--data_path', 'data/train_dev/duyet_v2_01/train_cnn_ket_hop.jsonl',\n"
        "    '--output_dir', str(REPORT_DIR),\n"
        "    '--dev_goc_path', 'mo_hinh/thu_nghiem/char_v1_01/snapshot/dev.csv',\n"
        "    '--dev_kho_path', 'mo_hinh/thu_nghiem/char_v1_01/snapshot/dev_kho.csv',\n"
        "    '--device', 'cpu'\n"
        "]\n"
        "subprocess.run(eval_cmd, check=True)\n"
    )

    # Ô 9: Hiển thị Báo Cáo Trực Quan trong Notebook
    add_code(
        "from IPython.display import Markdown, display\n"
        "report_file = REPORT_DIR / 'BAO_CAO_DANH_GIA.md'\n"
        "if report_file.exists():\n"
        "    display(Markdown(report_file.read_text(encoding='utf-8')))\n"
        "else:\n"
        "    print('Không tìm thấy file báo cáo markdown tại:', report_file)\n"
    )

    # Ô 10: Đóng gói Artifacts Kết Quả Về Drive
    add_code(
        "print('=== ĐỒNG BỘ ARTIFACTS KẾT QUẢ VỀ GOOGLE DRIVE ===')\n"
        "history_file = OUTPUT_CKPT_DIR / 'training_history.json'\n"
        "if history_file.exists():\n"
        "    print('Lịch sử huấn luyện:', history_file)\n"
        "best_head = OUTPUT_CKPT_DIR / 'best_linking_head.pt'\n"
        "if best_head.exists():\n"
        "    print(f'Mô hình Linking Head tốt nhất: {best_head} ({best_head.stat().st_size / 1024:.1f} KB)')\n"
        "print('Toàn bộ kết quả thí nghiệm đã được lưu an toàn tại:', EXP_DIR)\n"
        "print('HOÀN TẤT THÀNH CÔNG 100%!')\n"
    )

    notebook_dict = {
        "nbformat": 4,
        "nbformat_minor": 5,
        "metadata": {
            "accelerator": "GPU",
            "colab": {
                "name": "LienKet_ViDeBERTa_Drive.ipynb",
                "provenance": []
            },
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "name": "python"
            }
        },
        "cells": [dict(c, id=f"cell-{i:02d}") for i, c in enumerate(cells)]
    }

    out_path = Path("colab/linking_v1/LienKet_ViDeBERTa_Drive.ipynb")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(notebook_dict, f, ensure_ascii=False, indent=2)
    print("Created notebook successfully at:", str(out_path.resolve()))

if __name__ == "__main__":
    create_notebook()
